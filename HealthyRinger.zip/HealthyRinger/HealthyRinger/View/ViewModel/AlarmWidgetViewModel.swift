//
//  AlarmWidgetViewModel.swift
//  HealthyRinger
//
//  Created by Владимир Марышев on 06.08.2024.
//

import Foundation
