//
//  HealthyRingerApp.swift
//  HealthyRinger
//
//  Created by Владимир Марышев on 09.07.2024.
//

import SwiftUI

@main
struct HealthyRingerApp: App {
    
    var body: some Scene {
        WindowGroup {
            HomeView(alarmViewModel: AlarmViewModel())
        }
    }
}
