//
//  StyleView.swift
//  HealthyRinger
//
//  Created by Владимир Марышев on 22.07.2024.
//

import SwiftUI

extension Color {
    static let backGroundColorSet = Color("BackgroundColorSet")
}
